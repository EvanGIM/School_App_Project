/** Automatically generated file. DO NOT MODIFY */
package com.middleschool.sangha;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}